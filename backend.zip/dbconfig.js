const config = {
    user: "krishgondaliya",
    password: "9033702483@Abcd",
    server: "SNC-VAL-AILAB5\\SQLEXPRESS",
    database: "project",
    options: {
        trustedconnection: true,
        enableArithAbort: true,
        instancename: "SQLEXPRESS",
    },
    port: 55892,
};

module.exports = config;
