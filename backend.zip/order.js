class Order {
    constructor(id, name) {
        this.id = id;
        this.name = name;
        // this.Title = Title;
        // this.Quantity = Quantity;
        // this.Message = Message;
        // this.City = City;
    }
}

module.exports = Order;
